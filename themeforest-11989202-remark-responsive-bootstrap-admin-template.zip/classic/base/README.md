# Remark - Responsive Bootstrap Admin Template

THANK YOU FOR PURCHASING!

You can access the documentation: http://remark-docs.readthedocs.org/en/latest/

Fell free email us (support@amazingsurge.com) for support issues.
